<?php include('header.php')?>
	
	<div class="container-fluid body_wrapper">
	
		<div class="col-sm-2">
			
			<div class="row lft_conte">
				
				<div class="left_links">
					
					<p>Sports<i class="fa fa-angle-down"></i></p>
					
					<p>Gifts & Coupons<i class="fa fa-angle-down"></i></p>
					
					<p>Travel<i class="fa fa-angle-down"></i></p>
					
					<p>Special service<i class="fa fa-angle-down"></i></p>
					
					<p>Tickets & Experience<i class="fa fa-angle-down"></i></p>
					
					<p>Other areas<i class="fa fa-angle-down"></i></p>
					
				</div>
				
			</div>
			
		</div>
		
		<div class="col-sm-10">
			
			<div class="row">
				
				<div class="main_fluid">
					
					<div class="main_wrapper">
						
						<div class="top_headed">
							
							<div class="col-sm-4">
							
								<div class="left_part">
									
									<a href="#">All Listing</a>
									
									<a href="#">Sold Now</a>
									
									<a href="#">Auction</a>
									
								</div>
								
							</div>
							
							<div class="col-sm-8 text-right sort_part">
							
								<div class="left_part">
								
									<span>Sort by : </span>
									
									<a href="#">Popularity</a>
									
									<a href="#">Average</a>
									
									<a href="#">High to low</a>
									
									<a href="#">Low to High</a>
									
								</div>
								
							</div>
							
						</div>
						
						<div class="product_wrapper">
						
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('dummy/1.jpg');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('https://img2.newchic.com/thumb/view/oaupload/newchic/images/DC/ED/b1e1258b-86f7-45b5-905b-6ad678396d41.jpg');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.pngpix.com/wp-content/uploads/2016/06/PNGPIX-COM-Audi-Q5-Caractere-Black-Car-PNG-Image.png');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('https://images.philips.com/is/image/PhilipsConsumer/109B50_74-IMS-en_US?$jpglarge$&wid=1250');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.lohiaauto.com/download/wallpaper/png/HumsafarPassenger.png');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('https://4.imimg.com/data4/QB/AJ/MY-24817871/tvs-auto-rickshaw-500x500.jpg');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.pngpix.com/wp-content/uploads/2016/06/PNGPIX-COM-Jeep-Wrangler-PNG-Image-500x382.png');">

									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.pngpix.com/wp-content/uploads/2016/06/PNGPIX-COM-Red-McLaren-540C-Car-PNG-Image.png');">

									</div>
								
								</div>
								
							</div>
						
							
						</div>
						
					</div>
					
				</div>
				
				<div class="main_fluid">
					
					<div class="main_wrapper">
						
						<div class="top_headed">
							
							<div class="col-sm-4">
							
								<div class="left_part">
									
									<a href="#">All Listing</a>
									
									<a href="#">Sold Now</a>
									
									<a href="#">Auction</a>
									
								</div>
								
							</div>
							
							<div class="col-sm-8 text-right sort_part">
							
								<div class="left_part">
								
									<span>Sort by : </span>
									
									<a href="#">Popularity</a>
									
									<a href="#">Average</a>
									
									<a href="#">High to low</a>
									
									<a href="#">Low to High</a>
									
								</div>
								
							</div>
							
						</div>
						
						<div class="product_wrapper">
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('dummy/1.jpg');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('https://img2.newchic.com/thumb/view/oaupload/newchic/images/DC/ED/b1e1258b-86f7-45b5-905b-6ad678396d41.jpg');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.pngpix.com/wp-content/uploads/2016/06/PNGPIX-COM-Audi-Q5-Caractere-Black-Car-PNG-Image.png');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('https://images.philips.com/is/image/PhilipsConsumer/109B50_74-IMS-en_US?$jpglarge$&wid=1250');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.lohiaauto.com/download/wallpaper/png/HumsafarPassenger.png');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('https://4.imimg.com/data4/QB/AJ/MY-24817871/tvs-auto-rickshaw-500x500.jpg');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.pngpix.com/wp-content/uploads/2016/06/PNGPIX-COM-Jeep-Wrangler-PNG-Image-500x382.png');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
							<div class="col-sm-3 a_product">
							
								<div class="product_hvr">
								
									<div class="product_img" style="background: url('http://www.pngpix.com/wp-content/uploads/2016/06/PNGPIX-COM-Red-McLaren-540C-Car-PNG-Image.png');">
									
										<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

									</div>
									
									<div class="product_content">
										
										<h5>Orange Black Hi-Back Bean Bag</h5>
										
										<p class="s_s"><span class="left">Start : ₫ 200000</span> <span class="right">Sold : ₫ 350000</span></p>
										
									</div>
								
								</div>
								
							</div>
							
						</div>
						
					</div>
					
				</div>
				
			</div>
			
		</div>
		
	</div>
	<?php include('footer.php')?>
