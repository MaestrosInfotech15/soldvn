<?php include('header.php')?>

               
                <div class="span9" id="content">
                          	
                	
                <div  class=" row col-sm-8 margindiv">
                	
                	
                	<div  class="col-sm-4 div_count">
						<div class=triangle><i class="fa fa-eye ico" aria-hidden="true"></i></div>
                		
                		<p>users:</p>
                		<span class="value">1</span>
                	</div>
                		
                		
               <div  class="col-sm-4 div_count div_border1 value1 ">
						<div class= triangle1><i class="fa fa-user ico" aria-hidden="true"></i></div>
                		
                		<p>products:</p>
                		<span class="value2">1</span>
                	</div>
                	
                	
                 <div  class="col-sm-4 div_count div_border1">
						<div class= triangle2><i class="fa fa-usd ico" aria-hidden="true"></i></div>
                		
                		<p>Payment:</p>
                		<span class="value3">1</span>
                	</div>
                	
                  </div>
                  
                  <div  class=" row col-sm-8 margindiv">
                	
                	
                	<div  class="col-sm-4 div_count">
						<div class=triangle><i class="fa fa-eye ico" aria-hidden="true"></i></div>
                		
                		<p>Booking products</p>
                		<span class="value">1</span>
                		
                	</div>
                		
                		
               <div  class="col-sm-4 div_count div_border1 value1 ">
						<div class= triangle1><i class="fa fa-user ico" aria-hidden="true"></i></div>
                		
                		<p>categories:</p>
                		<span class="value2">1</span>
                	</div>
                	
                	
                 <div  class="col-sm-4 div_count div_border1">
						<div class= triangle2><i class="fa fa-usd ico" aria-hidden="true"></i></div>
                		
                		<p>Sellar:</p>
                		<span class="value3">1</span>
                	</div>
                	
                  </div>



                </div>


                	

			

<?php include('footer.php')?>

            