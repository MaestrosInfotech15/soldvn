<?php include('header.php')?>
	
	<div class="container-fluid show_wrapper">
	
		<div class="show_main col-sm-12">
		
			<div class="row">
			
				<div class="col-sm-5">

					<div class="product_img show" style="background: url('http://mccarthycjd.co.za/blog/dodge/wp-content/uploads/2016/05/dodge-charger-1.jpg');">

						<p class="bid_time"><span>17 Days</span><span id="txt"></span></p>

					</div>

				</div>

				<div class="col-sm-5 product_details">

					<h3>Dodge Charger R/T</h3>
					
					<p>
						
						Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since
						
					</p>
					
					<p>
					
						<strong>Starting bid:</strong> ₫300,000<br>

						<strong>Item condition:</strong> New<br>

						<strong>Product Location:</strong> Ho Chi Minh City / District 2

					</p>
					
					<div class="">
					
						<input type="text" class="form-control" value="2000000" style="max-width:200px; float: left;">
						
						<button class="btn btn-login">
							
							BID
							
						</button>
						
					</div>

				</div>
								
			</div>
									
		</div>
		
	</div>
	
	<?php include('footer.php')?>